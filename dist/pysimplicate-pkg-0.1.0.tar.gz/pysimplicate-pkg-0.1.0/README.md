# PySimplicate
Simplicate api library for Python

I wrote this package to automate various operations in Simplicate like making exports, adding data and various reports.

It is, however, far from complete. Many calls in the Simplicate api are still missing. So feel free to contribute...

Hans-Peter
